# 📊 CharterAI — AI Project Charter Generator

> A client-side web application for Project Management Officers. Generate comprehensive, PMO-grade Project Charters in seconds using AI — including Executive Summary, RACI Matrix, Risk Register, Communication Plan, and Milestones. Export directly to Microsoft Word.

[![Live Demo](https://img.shields.io/badge/Live%20Demo-GitHub%20Pages-blue?logo=github)](https://makarich1.github.io/ai-project-charter-generator/)
[![UI: Tailwind CSS](https://img.shields.io/badge/UI-Tailwind_CSS-38B2AC?logo=tailwind-css&logoColor=white)](#)
[![JS: Vanilla](https://img.shields.io/badge/JS-Vanilla-F7DF1E?logo=javascript&logoColor=black)](#)
[![AI: Google Gemini](https://img.shields.io/badge/AI-Google%20Gemini-4285F4?logo=google&logoColor=white)](#)
[![Deploy: Zero-Build](https://img.shields.io/badge/Build-Zero--Pipeline-success)](#)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## ⚡ What it does

Creating a solid Project Charter from initial requirements can take 2–4 hours of a PMO's time. This tool reduces that to **under 30 seconds**.

Enter your project parameters → AI generates a structured, industry-standard charter → Export to Word.

<!-- Add a GIF here: assets/demo/demo.gif -->
<!-- ![Demo](assets/demo/demo.gif) -->

### Output includes

| Section | Details |
|---|---|
| **Executive Summary** | 3–4 sentences covering purpose, outcome & strategic alignment |
| **Scope Statement** | In-scope and out-of-scope items, specific and measurable |
| **RACI Matrix** | Role-based accountability matrix (min. 5 roles) |
| **Risk Register** | 5 risks with Probability × Impact scoring (9/6/4/3/1 scale) |
| **Communication Plan** | Audience, content, frequency, and channel per stakeholder group |
| **Milestones** | Phase-appropriate milestones adapted to the selected methodology |

---

## 🚀 Quick Start (2 steps)

**Step 1** — Get a free Google Gemini API key at [aistudio.google.com](https://aistudio.google.com/app/apikey) *(Free tier: 15 req/min, 1500 req/day)*

**Step 2** — Open the app:

```bash
# Option A: Use the live GitHub Pages version (no setup)
# → https://makarich1.github.io/ai-project-charter-generator/

# Option B: Clone and open locally
git clone https://github.com/makarich1/ai-project-charter-generator.git
cd ai-project-charter-generator
open index.html   # macOS
start index.html  # Windows
```

No npm. No build step. No server. Just open and use.

---

## 🏛 Architecture & Design Decisions

This project follows a strict **"minimum viable footprint"** philosophy:

```
ai-project-charter-generator/
├── index.html          ← The entire application (UI + logic + prompts)
├── README.md
└── .github/
    └── workflows/
        └── deploy.yml  ← Auto-deploy to GitHub Pages on push
```

**Why a single file?**

- Zero dependency management — no `package.json`, no versioning conflicts
- Instant GitHub Pages deployment — push to `main`, it's live in 60 seconds
- Portable — works offline after first load (fonts/CDNs aside)
- Easier to share, audit, and fork

**Why Vanilla JS over React/Vue?**

A single-purpose productivity utility benefits most from absolute minimal overhead. The interaction model is simple: fill form → call API → render output. No state management framework is justified.

**Why Google Gemini Flash?**

- Free tier with generous limits (suitable for portfolio demos and personal use)
- `response_mime_type: "application/json"` guarantees clean JSON output at the API level — no markdown fence parsing required
- ~1–2s response time on Flash model

---

## 💼 Business Context

Built by a working PMO professional managing IT projects across financial institutions (Nordea, ING Bank Śląski, Volkswagen Financial Services). The charter output structure reflects actual artefacts used in enterprise project governance.

The prompt engineering follows PMO best practices:
- Risk scoring aligned to standard P×I matrices (9/6/4/3/1)
- RACI rules enforced (exactly one Accountable per row)
- Methodology-aware output: Agile → sprint milestones, Waterfall → phase gates, PRINCE2 → formal governance

---

## 🔒 Privacy

- Your API key is stored **only in your browser's `localStorage`**
- No analytics, no backend, no data collection
- All processing happens client-side or directly between your browser and Google's Gemini API

---

## 🗺 Roadmap

- [x] v1.0 — Core charter generation (6 sections), Word export, JSON export
- [ ] v1.1 — PDF export via browser print API
- [ ] v1.2 — Template selector (IT project vs. business transformation vs. compliance)
- [ ] v2.0 — Polish language output option
- [ ] v2.1 — Claude API support alongside Gemini

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

*Part of the [PMO AI Toolkit](https://github.com/makarich1/pmo-ai-toolkit) project.*
